$("[data-fancybox]").fancybox({
	iframe : {
		preload: false
	}
});